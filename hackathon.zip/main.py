from PIL import Image
from pytesseract import pytesseract
import mysql.connector
import geocoder
import math
import os

def distance(lat1, lon1, lat2, lon2):
    R = 6371  
    
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)
    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)

    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c

    return distance

def max_keys(d):
    max_value = max(d.values())
    return [k for k, v in d.items() if v == max_value]





path_to_tesseract = os.path.abspath("/Program Files/Tesseract-OCR/tesseract.exe")
image_path = os.path.abspath("C:/Users/saake/Desktop/Hackathon/Sampl-prescription.png")
  
img = Image.open(image_path)
  

pytesseract.tesseract_cmd = path_to_tesseract
text = pytesseract.image_to_string(img)
text = text.split()
Druglist = []

with open("C:/Users/saake/Desktop/Hackathon/drugs.txt") as f:
   lines = f.readlines()
   for i in lines:
    i = i.strip() 
    for j in text:
        if i.lower() == j.lower():
             Drug = i
             Druglist.append(Drug)
file_path = "C:/Users/saake/Desktop/Hackathon/drugs.txt"

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Quicko",
  database = "Shops"
)

mycursor = mydb.cursor(buffered=True)

sql4 = "SELECT table_name FROM information_schema.tables WHERE table_schema = %s"
val4 = ("Shops", )
mycursor.execute(sql4, val4)

tablenamelist = []

for table in mycursor:
    tablenamelist.append(table[0])

dict = {}
for table in tablenamelist:
    sql3 = "SELECT * FROM {} WHERE name = %s".format(table)
    Number_Of_Matches = 0
    for i in Druglist:
        val3 = (i, )
        mycursor.execute(sql3, val3)        
        if mycursor.fetchone():
            Number_Of_Matches += 1
    dict[table] = Number_Of_Matches


Delivery_location = max_keys(dict)

dict2 = {}
if len(Delivery_location) > 1:
    ip = geocoder.ip('me')
    My_latitude = ip.latlng[0]
    My_longitude = ip.latlng[1]
    for shop in Delivery_location:
        sql0 = "SELECT latitude FROM locations WHERE name = %s"
        mycursor.execute(sql0, (shop,))
        Dest_Latitude = mycursor.fetchone()[0]
        sql00 = "SELECT longitude FROM locations WHERE name = %s"
        mycursor.execute(sql00, (shop,))
        Dest_Longitude = mycursor.fetchone()[0]
        dict2[shop] = distance(My_latitude, My_longitude, Dest_Latitude, Dest_Longitude)
        print(dict2[shop])

    Delivery_location = max_keys(dict2)

print(Delivery_location[0])

mydb.commit()
mycursor.close()
mydb.close()
 

