from PIL import Image
from pytesseract import pytesseract
import mysql.connector
  

path_to_tesseract = r"C:/Program Files/Tesseract-OCR/tesseract.exe"
image_path = "C:/Users/saake/Desktop/Hackathon/Sampl-prescription.png"
  
img = Image.open(image_path)
  

pytesseract.tesseract_cmd = path_to_tesseract
text = pytesseract.image_to_string(img)
text = text.split()
Druglist = []

with open("C:/Users/saake/Desktop/Hackathon/drugs.txt") as f:
    lines = f.readlines()
    for i in lines:
        i = i.strip() 
        for j in text:
            if i.lower() == j.lower():
                Drug = i
                Druglist.append(Drug)



mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Quicko",
  database = "Shops"
)


mycursor = mydb.cursor(buffered=True)

sql4 = "SELECT table_name FROM information_schema.tables WHERE table_schema = %s"
val4 = ("Shops", )
mycursor.execute(sql4, val4)

for i in Druglist:
    for table in mycursor:
        tablename = table[0]
        sql3 = "SELECT * FROM tablename WHERE name = %s"
        val3 = (i, )
        mycursor.execute(sql3, val3)        
        
        if mycursor.fetchone():
            print(Druglist[i] + " is available in " + table[0])


mydb.commit()
mycursor.close()
mydb.close()
